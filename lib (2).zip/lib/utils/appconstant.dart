 class AppConstant{
   static const String BASE_URL = "http://kolacut.kvpscampuscare.com/";
   static const String SEND_OTP="public/api/shop-login";
   static const String REGISTER="public/api/shop-register";
   static const String ADD_EMPLOYEE="public/api/add-employee";
   static const String GET_EMPLOYEE_LIST="public/api/manage-staff";
   static const String GET_EMPLOYEE_PROFILE="public/api/staff-detail";
   static const String ADD_SLOT="public/api/add-slots";
   static const String DASHBOARD_DATA="public/api/shop-dashboard";
   static const String ADMIN_SERVICE="public/api/shop-service";
   static const String SHOP_PROFILE="public/api/shop-detail";
   static const String COUPON_LIST="public/api/manage-coupon";
   static const String ADD_COUPON="public/api/add-coupon";
   static const String ADD_SERVICE="public/api/add-service";
   static const String SHOP_SERVICE="public/api/get-service";
   static const String UPDTE_SHOP="public/api/update-shop";
   static const String ENABLE_DESABLE="public/api/disable-account";
   static const String DELETE_COUPON="public/api/delete-coupon";
   static const String DELETE_ADD_SERVICE='public/api/delete-service';
   static const String UPDATE_PRICE="public/api/update-service";
   static const String GET_ALL_BOOKING="public/api/manage-bookings";
   static const String ACCEPT_BOOKING="public/api/accept-booking";
   static const String COMPLETE_BOOKIND="public/api/booking-completed";

}