import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screen/homebottombar.dart';
import 'screen/login.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  final String? session = prefs.getString('session');
  runApp(MyApp(session: session));
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key, this.session}) : super(key: key);
  final String? session;


  @override

  Widget build(BuildContext context) {
    print(session);
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: session == null ? const LoginPage() : const HomeBottomBar(),
    );
  }
}

// void main() {
//   runApp(MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   final box = GetStorage();
//   final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
//
//
//   @override
//   Widget build(BuildContext context) {
//     // late var a;
//     // late var b;
//     // a = _prefs.then((SharedPreferences prefs) {
//     //   return prefs.getInt('token') ?? 0;
//     // });
//     // if (a.toString().trim() != null || a.toString().trim() != "") {
//     //   b = HomeBottomBar();
//     // } else
//     //   {
//     //     b = LoginPage();
//     //   }
//
//
//     return GetMaterialApp(debugShowCheckedModeBanner: false, home:Firstpage() );
//   }
// }
//
// class Firstpage extends StatefulWidget {
//   const Firstpage({Key? key}) : super(key: key);
//
//
//
//   @override
//   State<Firstpage> createState() => _FirstpageState();
// }
//
// class _FirstpageState extends State<Firstpage> {
//
//   final box = GetStorage();
//   final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();
//
//   late var a;
//   late var b;
//   String  toke="";
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//
//     a = _prefs.then((SharedPreferences prefs) {
//       toke=  prefs.getString('token')!;
//       return prefs.getString('token') ?? "";
//     });
//     if ( toke.toString().trim() == "") {
//       b = LoginPage();
//     } else
//     {
//       b = HomeBottomBar();
//     }
//
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return b;
//   }
// }


