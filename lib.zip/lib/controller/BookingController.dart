import 'dart:convert';

import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:kolacur_admin/model/AcceptBookigPojo.dart';
import 'package:kolacur_admin/model/AllBookingPojo.dart';
import '../services/ApiCall.dart';
import '../utils/CommomDialog.dart';
import '../utils/appconstant.dart';

class BookingController extends GetxController {
  var bookingPojo = AllBookingPojoo().obs;
  var acceptBookingPojo = AcceptBookigPojo().obs;
  final box = GetStorage();
  var lodaer = true;
  var shopId = "".obs;
  List<SlotDetail>? slotDetail = [];

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  void filterWithDate(selectedDate) {
    if (bookingPojo.value.slotDetail!.isNotEmpty) {
      slotDetail = [];
      for (var i = 0; i < bookingPojo.value.slotDetail!.length; i++) {
        print(bookingPojo.value.slotDetail![i].date.toString());
        if (bookingPojo.value.slotDetail![i].date!.compareTo(selectedDate) ==
            0) {
          slotDetail!.add(bookingPojo.value.slotDetail![i]);
        } else {
        }
      }
      update();
      print(" <><><><><><><><><><><><><>");
      print(slotDetail!.length.toString() + " <><><><><><><><><><><><><>");
    }
  }

  void clearDateFilter(){
    slotDetail =bookingPojo.value.slotDetail!;
    update();
  }

  @override
  void onReady() {
    //session_id
    super.onReady();
    print("SDLKFJKLSDFJDSprofile");
    print(box.read('session'));
    getBookingList();
  }

  void getBookingList() async {
    Map map;
    map = {"session_id": box.read('session')};
    //map = {"session_id": "TXKe48DXicKoAjkyEOgXWqU3VuVZqdHm"};
    print("API HIT HIT HIT HIT");
    try {
      CommonDialog.showLoading(title: "Please waitt...");
      final response =
          await APICall().registerUrse(map, AppConstant.GET_ALL_BOOKING);
      print(response);
      if (bookingPojo.value.message == "No Data found") {
        //   print(response);
        CommonDialog.hideLoading();
        CommonDialog.showsnackbar("No Data found");
      } else {
        CommonDialog.hideLoading();
        bookingPojo.value = allBookingPojoFromJson(response);
        slotDetail = bookingPojo.value.slotDetail;
        update();
        lodaer = false;
      }
    } catch (error) {
      print(error);
      CommonDialog.hideLoading();
    }
  }

  void acceptBooking(bookingId) async {
    Map map;
    map = {"session_id": box.read('session'), "booking_id": bookingId};
    //map = {"session_id": "TXKe48DXicKoAjkyEOgXWqU3VuVZqdHm"};
    print("API HIT HIT HIT HIT");
    try {
      // CommonDialog.showLoading(title: "Please waitt...");
      final response =
          await APICall().registerUrse(map, AppConstant.ACCEPT_BOOKING);
      print(response);
      // CommonDialog.hideLoading();
      final body = json.decode(response);
      // lodaer = false;
      //         leaveListUpdated("PqtoOdpQ0SBVTMT0a15gnT7euR9x8fO6");
      //         update();
      if (body['status'] == 200) {
        lodaer = false;
        acceptBookingPojo.value = acceptBookigPojoFromJson(response);
        CommonDialog.showsnackbar(acceptBookingPojo.value.message);
        getUpdatedBookingList();
        update();
      } else {
        CommonDialog.showsnackbar(
            "Please try again,or contact to kolacut admin");
      }
      update();
    } catch (error) {
      print(error);
      // CommonDialog.hideLoading();
    }
  }

  void getUpdatedBookingList() async {
    lodaer = false;
    update();
    Map map;
    map = {"session_id": box.read('session')};
    //map = {"session_id": "TXKe48DXicKoAjkyEOgXWqU3VuVZqdHm"};
    print("API HIT HIT HIT HIT");
    try {
      //CommonDialog.showLoading(title: "Please waitt...");
      final response =
          await APICall().registerUrse(map, AppConstant.GET_ALL_BOOKING);
      print(response);
      // Navigator.pop(context);
      if (bookingPojo.value.message == "No Data found") {
        //   print(response);

        CommonDialog.showsnackbar("No Data found");
      } else {
        bookingPojo.value.slotDetail!.clear();
        update();
        bookingPojo.value = allBookingPojoFromJson(response);
        update();
        lodaer = false;
      }
    } catch (error) {
      print(error);
    }
  }
}
